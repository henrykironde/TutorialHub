import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Random;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLException;
import javax.media.opengl.glu.GLU;
import javax.swing.*;
import com.sun.opengl.util.FPSAnimator;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureCoords;
import com.sun.opengl.util.texture.TextureIO;
import static javax.media.opengl.GL.*;
import static java.awt.event.KeyEvent.*;

/**
 * NeHe Lesson 19: Particle Engine Using Triangle Strips
 * 
 * Change the "squarish" explosion to a "round" explosion
 */
public class NeheJOGL19Particle extends JPanel implements GLEventListener, KeyListener {
   private static final int REFRESH_FPS = 60;    // Display refresh frames per second
   private GLU glu;             // For the GL Utility
   final FPSAnimator animator;  // Used to drive display() 
   GLCanvas canvas;
   
   private static final int MAX_PARTICLES = 1000; // max number of particles
   private Particle[] particles = new Particle[MAX_PARTICLES];

   // Pull forces in each direction
   private static float forceX = 0.0f;
   private static float forceY = -0.8f; // gravity
   private static float forceZ = 0.0f;

   private static boolean enabledRainbow = true; // rainbow mode
   private static boolean enabledBurst = false; // another burst?

   private static float slowdown = 2.0f;
   
   // Global speed for all the particles
   private static float speedXGlobal = 0.0f;
   private static float speedYGlobal = 0.0f;
   private static float zoom = -40.0f; // Used To Zoom Out

   private static final float[][] colors = // Rainbow Of 12 Colors
   { { 1.0f, 0.5f, 0.5f }, { 1.0f, 0.75f, 0.5f }, { 1.0f, 1.0f, 0.5f },
         { 0.75f, 1.0f, 0.5f }, { 0.5f, 1.0f, 0.5f }, { 0.5f, 1.0f, 0.75f },
         { 0.5f, 1.0f, 1.0f }, { 0.5f, 0.75f, 1.0f }, { 0.5f, 0.5f, 1.0f },
         { 0.75f, 0.5f, 1.0f }, { 1.0f, 0.5f, 1.0f }, { 1.0f, 0.5f, 0.75f } };
   private static int currColor = 0; // Current Color Selection
   private static int colorDelayCount = 0; // rainbow effect delay

   // Texture applied over the shape
   private Texture texture;
   private String textureFileName = "images/particle.png";
   private String textureFileType = ".png";

   // Texture image flips vertically. Shall use TextureCoords class to retrieve the
   // top, bottom, left and right coordinates.
   private float textureTop;
   private float textureBottom;
   private float textureLeft;
   private float textureRight;

   // Constructor
   public NeheJOGL19Particle() {
      canvas = new GLCanvas();
      this.setLayout(new BorderLayout());
      this.add(canvas, BorderLayout.CENTER);
      canvas.addGLEventListener(this);
      canvas.addKeyListener(this);
      canvas.setFocusable(true);  // To receive key event
      canvas.requestFocus();
   
      // Run the animation loop using the fixed-rate Frame-per-second animator,
      // which calls back display() at this fixed-rate (FPS).
      animator = new FPSAnimator(canvas, REFRESH_FPS, true);
   }

   // Main program
   public static void main(String[] args) {
      final int WINDOW_WIDTH = 320;
      final int WINDOW_HEIGHT = 240;
      final String WINDOW_TITLE = "Nehe #19: Particle Engine Using Triangle Strips";

      JFrame frame = new JFrame();
      final NeheJOGL19Particle joglMain = new NeheJOGL19Particle();
      frame.setContentPane(joglMain);
      frame.addWindowListener(new WindowAdapter() {
         @Override 
         public void windowClosing(WindowEvent e) {
            // Use a dedicate thread to run the stop() to ensure that the
            // animator stops before program exits.
            new Thread() {
               @Override 
               public void run() {
                  joglMain.animator.stop(); // stop the animator loop
                  System.exit(0);
               }
            }.start();
         }
      });
      frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      frame.setTitle(WINDOW_TITLE);
      frame.setVisible(true);
      joglMain.animator.start(); // start the animation loop
   }

   // ------ Implement methods declared in GLEventListener ------

   /**
    * Called by the drawable immediately after the OpenGL context is initialized for
    * the first time. Can be used to perform one-time OpenGL initialization such as
    * setup of lights and display lists. Run only once.
    */
   @Override
   public void init(GLAutoDrawable drawable) {
      // Get the OpenGL graphics context
      GL gl = drawable.getGL();
      // GL Utilities
      glu = new GLU();
      // Enable smooth shading, which blends colors nicely across a polygon, and
      // smoothes out lighting.
      gl.glShadeModel(GL_SMOOTH);
      // Set background color (in RGBA). Alpha of 0 for total transparency
      gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
      // Setup the depth buffer & enable the depth testing
      gl.glClearDepth(1.0f);
      // gl.glEnable(GL_DEPTH_TEST); // enables depth testing
      // gl.glDepthFunc(GL_LEQUAL); // the type of depth test to do
      // We want the best perspective correction to be done
      gl.glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

      gl.glEnable(GL_BLEND); // Enable Blending
      gl.glBlendFunc(GL_SRC_ALPHA, GL_ONE); // Type Of Blending To Perform
      gl.glHint(GL_POINT_SMOOTH_HINT, GL_NICEST); // Really Nice Point Smoothing

      // Load the texture image
      try {
         // Create a OpenGL Texture object from (URL, mipmap, file suffix)
         // Use URL so that can read from JAR and disk file.
         texture = TextureIO.newTexture(
               this.getClass().getResource(textureFileName), false, textureFileType);
      } catch (GLException e) {
         e.printStackTrace();
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Use linear filter for texture if image is larger than the original texture
      gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      // Use linear filter for texture if image is smaller than the original texture
      gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

      // Texture image flips vertically. Shall use TextureCoords class to retrieve
      // the top, bottom, left and right coordinates, instead of using 0.0f and 1.0f.
      TextureCoords textureCoords = texture.getImageTexCoords();
      textureTop = textureCoords.top();
      textureBottom = textureCoords.bottom();
      textureLeft = textureCoords.left();
      textureRight = textureCoords.right();

      // Initialize the particles
      for (int i = 0; i < MAX_PARTICLES; i++) {
         particles[i] = new Particle();
      }
   }

   /**
    * Called by the drawable to initiate OpenGL rendering.
    */
   @Override
   public void display(GLAutoDrawable drawable) {
      // Get the OpenGL graphics context
      GL gl = drawable.getGL();
      // Clear the screen and the depth buffer
      gl.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      // Reset the view (x, y, z axes back to normal)
      gl.glLoadIdentity();

      // Render the particles
      for (int i = 0; i < MAX_PARTICLES; i++) {
         if (particles[i].active) {
            // Draw The Particle Using Our RGB Values, Fade The Particle Based On
            // It's Life
            gl.glColor4f(particles[i].r, particles[i].g, particles[i].b,
                  particles[i].life);

            texture.enable();
            texture.bind();

            gl.glBegin(GL_TRIANGLE_STRIP); // Build Quad From A Triangle Strip

            float x = particles[i].x;
            float y = particles[i].y;
            float z = particles[i].z + zoom;

            gl.glTexCoord2d(textureRight, textureTop);
            gl.glVertex3f(x + 0.5f, y + 0.5f, z); // Top Right
            gl.glTexCoord2d(textureLeft, textureTop);
            gl.glVertex3f(x - 0.5f, y + 0.5f, z); // Top Left
            gl.glTexCoord2d(textureRight, textureBottom);
            gl.glVertex3f(x + 0.5f, y - 0.5f, z); // Bottom Right
            gl.glTexCoord2d(textureLeft, textureBottom);
            gl.glVertex3f(x - 0.5f, y - 0.5f, z); // Bottom Left
            gl.glEnd();

            // Move the particle
            particles[i].x += particles[i].speedX / (slowdown * 1000.0f);
            particles[i].y += particles[i].speedY / (slowdown * 1000.0f);
            particles[i].z += particles[i].speedZ / (slowdown * 1000.0f);

            // Apply the gravity force
            particles[i].speedX += forceX;
            particles[i].speedY += forceY;
            particles[i].speedZ += forceZ;

            // Take away some life
            particles[i].life -= particles[i].fade;
            if (particles[i].life < 0.0f) {  // check for burst also
               // If the particle is dead (burnt out), we'll rejuvenate it. We do
               // this by giving it full life and a new fade speed.
               particles[i].regenerate();
            }
            
            if (enabledBurst) {
               particles[i].burst();
            }
         }
      }
      
      // update the color
      colorDelayCount++;
      if (colorDelayCount > 25 && enabledRainbow) {
         currColor = (currColor + 1) % colors.length;
         colorDelayCount = 0;
      }
      if (enabledBurst) enabledBurst = false;
   }

   /**
    * Called by the drawable during the first repaint after the component has been
    * resized. Run at least once when the window is first set to visible.
    */
   @Override
   public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
      // Get the OpenGL graphics context
      GL gl = drawable.getGL();

      if (height == 0) {
         height = 1; // prevent divide by zero
      }
      float aspect = (float)width / height;

      // Set the viewport (display area) to cover the entire window
      gl.glViewport(0, 0, width, height);

      // Enable perspective view (where far objects are smaller)
      gl.glMatrixMode(GL_PROJECTION);
      gl.glLoadIdentity(); // reset
      glu.gluPerspective(45.0f, aspect, 0.1f, 200.0f); // fovy, aspect, zNear, zFar

      // Enable the model view - any new transformations will affect the model-view
      // matrix
      gl.glMatrixMode(GL_MODELVIEW);
      gl.glLoadIdentity(); // reset
   }

   /**
    * Called when the display mode (eg. resolution) has been changed.
    */
   @Override
   public void displayChanged(GLAutoDrawable drawable, boolean modeChanged,
         boolean deviceChanged) {}

   class Particle {
      boolean active; // always active in this program
      float life; // life time
      float fade; // fading speed, which reduces the life time
      float r, g, b; // color
      float x, y, z; // position
      float speedX, speedY, speedZ; // speed in the direction

      private Random rand = new Random();

      // Constructor
      public Particle() {
         active = true;
         burst();
      }

      public void burst() {
         life = 1.0f;

         // Set a random fade speed value between 0.003 and 0.103
         fade = rand.nextInt(100) / 1000.0f + 0.003f;

         // Set the initial position
         x = y = z = 0.0f;
         
         // Generate a random speed and direction in polar coordinate, then resolve
         // them into x and y.
         // Set Random speed between -25 to +25
         float speed = (rand.nextInt(50) - 25.0f);
         float angle = (float)Math.toRadians(rand.nextInt(360));

         // Multiplied by 10 to create a spectacular explosion when the program first starts
         speedX = speed * (float)Math.cos(angle) * 10.0f;
         speedY = speed * (float)Math.sin(angle) * 10.0f;
         speedZ = (rand.nextInt(50) - 25.0f) * 10.0f;

         // Pick a random color from the colors array
         int colorIndex = rand.nextInt(colors.length);
         r = colors[colorIndex][0];
         g = colors[colorIndex][1];
         b = colors[colorIndex][2];
      }

      public void regenerate() {
         life = 1.0f;
         fade = rand.nextInt(100) / 1000.0f + 0.003f;
         x = y = z = 0.0f;

         // Generate a random speed and direction in polar coordinate, then resolve
         // them into x and y. Increase the Random speed to between -30 to +30
         float speed = (rand.nextInt(60) - 30.0f);
         float angle = (float)Math.toRadians(rand.nextInt(360));

         // Not multiply by 10 for subsequent launch
         speedX = speed * (float)Math.cos(angle) + speedXGlobal;
         speedY = speed * (float)Math.sin(angle) + speedYGlobal;
         speedZ = rand.nextInt(60) - 30.0f;

         // Use the current color
         r = colors[currColor][0];
         g = colors[currColor][1];
         b = colors[currColor][2];
      }
   }

   @Override
   public void keyPressed(KeyEvent e) {
      switch (e.getKeyCode()) {
         case VK_UP: // increase the upward pull forces
            if (speedYGlobal < 200.0f)
               speedYGlobal += 1.0f;
            break;
         case VK_DOWN: // increase the upward pull forces
            if (speedYGlobal > -200.0f)
               speedYGlobal -= 1.0f;
            break;
         case VK_RIGHT: // increase the upward pull forces
            if (speedXGlobal < 200.0f)
               speedXGlobal += 1.0f;
            break;
         case VK_LEFT: // increase the upward pull forces
            if (speedXGlobal > -200.0f)
               speedXGlobal -= 1.0f;
            break;
         case VK_NUMPAD8: // increase the upward pull forces
            if (forceY < 1.5f)
               forceY += 0.01f;
            break;
         case VK_NUMPAD2: // increase the upward pull forces
            if (forceY > -1.5f)
               forceY -= 0.01f;
            break;
         case VK_NUMPAD6: // increase the upward pull forces
            if (forceX < 1.5f)
               forceX += 0.01f;
            break;
         case VK_NUMPAD4: // increase the upward pull forces
            if (forceX > -1.5f)
               forceX -= 0.01f;
            break;
         case VK_PAGE_UP:
            zoom -= 0.1f;
            break;
         case VK_PAGE_DOWN:
            zoom += 0.1f;
            break;
         case VK_ADD:
            if (slowdown > 1.0f)
               slowdown -= 0.01f;
            break;
         case VK_SUBTRACT:
            if (slowdown < 4.0f)
               slowdown += 0.01f;
            break;
         case VK_TAB:
         case VK_T:
            if (!enabledBurst) enabledBurst = true;
            break;
         case KeyEvent.VK_ENTER: // toggle rainbow
            enabledRainbow = !enabledRainbow;
            break;
         case KeyEvent.VK_SPACE: // go for the next color
            currColor = (currColor + 1) % colors.length;
            break;

      }
   }

   @Override
   public void keyReleased(KeyEvent e) {}

   @Override
   public void keyTyped(KeyEvent e) {}
}