import javax.swing.JApplet;

/**
 * NeHe Lesson 1: Setting Up (Run as Applet)
 */
public class NeheJOGL01Applet extends JApplet {
   NeheJOGL01SetupGLCanvas joglMain;
   
   @Override
   public void init() {
      joglMain = new NeheJOGL01SetupGLCanvas();
      this.setContentPane(joglMain);
      joglMain.animator.start(); // start the animation loop
   }
   
   @Override
   public void start() {
   }
   
   @Override
   public void stop() {
   }
   
   @Override
   public void destroy() {
      // Use a dedicate thread to run the stop() to ensure that the
      // animator stops before program exits.
      new Thread() {
         @Override 
         public void run() {
            joglMain.animator.stop(); // stop the animator loop
            System.exit(0);
         }
      }.start();
   }
}
